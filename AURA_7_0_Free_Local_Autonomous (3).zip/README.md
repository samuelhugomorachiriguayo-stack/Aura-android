# AURA 7.0 — Cerebro Local Gratis

AURA es una asistente virtual local-first para Android. Usa Qwen3-1.7B GGUF mediante llama.cpp y Android TextToSpeech. No necesita una API de IA de pago.

## Módulos incorporados
- Cerebro conversacional local
- Psicología y bienestar (educativo y seguro)
- Hipnosis, autohipnosis educativa y relajación (sin promesas médicas)
- Salud y medicina educativa
- Cirugía educativa y simulación académica (no instrucciones operativas peligrosas)
- Academia para cursos, lecciones, ejercicios y evaluaciones
- Music Pro
- Soporte técnico
- Marketing y redes sociales
- Banca y privacidad seguras

## Base de conocimiento offline
Incluye una pequeña biblioteca local orientada por temas para ayudar a aterrizar respuestas del modelo. Las fuentes de referencia indicadas son OMS, APA, NCCIH/NIH, MedlinePlus y NCBI.

## Importante
El modelo local es pequeño. Esta versión amplía su comportamiento, seguridad y contexto offline, pero no convierte mágicamente un modelo de 1.7B en una autoridad clínica. Las respuestas médicas son educativas y deben verificarse con profesionales y fuentes oficiales, especialmente para decisiones urgentes o individualizadas.

## Gratis
La descarga del modelo y la compilación usan recursos públicos/gratuitos. No se incluye ningún servicio de IA de pago ni se pide API key.
