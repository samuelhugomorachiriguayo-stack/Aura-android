AURA HIPNOSIS — BASE EDUCATIVA
Fuente principal para evidencia y límites: National Center for Complementary and Integrative Health (NCCIH/NIH).

Alcance: historia de la hipnosis, atención, sugestión, autohipnosis educativa, relajación, respiración, meditación y lectura crítica de evidencia.

La hipnosis ha sido estudiada en distintas condiciones y la evidencia varía según el uso. No se deben prometer curas ni usar hipnosis como sustituto de atención convencional.
