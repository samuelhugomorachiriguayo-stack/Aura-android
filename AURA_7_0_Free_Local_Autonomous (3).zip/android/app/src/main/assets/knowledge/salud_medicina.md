AURA SALUD — BASE EDUCATIVA
Fuente principal para orientación y verificación: Organización Mundial de la Salud (OMS), MedlinePlus y recursos educativos de NCBI/NIH.

Alcance: anatomía, fisiología, prevención, enfermedades, síntomas, pruebas, medicamentos, primeros auxilios y explicación educativa de especialidades y procedimientos.

Regla: esta biblioteca no autoriza diagnóstico definitivo ni instrucciones peligrosas de cirugía o procedimientos invasivos. Para síntomas graves o emergencias, la prioridad es la atención profesional.

La OMS recomienda supervisión, seguridad, evaluación y protección de privacidad al usar IA en salud. La información generada por IA puede ser falsa, inexacta, sesgada o incompleta.
