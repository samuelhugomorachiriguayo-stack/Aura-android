package com.aura.assistant

/** Local-first router: the free on-device brain is always preferred. */
class HybridRouter {
    fun mode() = "LOCAL"
}
