package com.aura.assistant

import android.content.Context

/** Small, bundled, offline-first knowledge index used to ground the local model. */
class LocalKnowledge(private val context: Context) {
    private val documents: List<Pair<String, String>> by lazy { loadDocuments() }

    private fun loadDocuments(): List<Pair<String, String>> {
        val dir = context.assets.list("knowledge") ?: return emptyList()
        return dir.filter { it.endsWith(".md") }.mapNotNull { name ->
            runCatching {
                val text = context.assets.open("knowledge/$name").bufferedReader().use { it.readText() }
                name to text
            }.getOrNull()
        }
    }

    fun retrieve(query: String, limit: Int = 2): String {
        if (documents.isEmpty()) return ""
        val normalized = query.lowercase()
            .replace(Regex("[^a-záéíóúüñ0-9\\s]"), " ")
        val terms = normalized.split(Regex("\\s+"))
            .filter { it.length >= 3 }
            .distinct()
        val scored = documents.map { (name, text) ->
            val body = text.lowercase()
            val score = terms.count { term -> body.contains(term) } +
                when {
                    name.contains("salud") && terms.any { it in setOf("salud", "enfermedad", "síntoma", "cirugía", "medicina") } -> 3
                    name.contains("psicologia") && terms.any { it in setOf("psicologia", "psicología", "ansiedad", "depresión", "emocional") } -> 3
                    name.contains("hipnosis") && terms.any { it in setOf("hipnosis", "hipnosis", "relajación", "sugestión") } -> 3
                    name.contains("academia") && terms.any { it in setOf("curso", "clase", "examen", "aprender") } -> 3
                    name.contains("musica") && terms.any { it in setOf("música", "musica", "rap", "beat", "dj", "mezcla") } -> 3
                    else -> 0
                }
            Triple(score, name, text)
        }.filter { it.first > 0 }
            .sortedByDescending { it.first }
            .take(limit)

        if (scored.isEmpty()) return ""
        return buildString {
            append("\n\n[CONOCIMIENTO LOCAL VERIFICADO — USO EDUCATIVO]\n")
            scored.forEach { (_, name, text) ->
                append("\n--- $name ---\n")
                append(text.trim())
                append("\n")
            }
            append("\nFin del contexto local. No inventes datos que no estén sustentados aquí; para información médica actualizada, recomienda consultar fuentes sanitarias oficiales o un profesional.\n")
        }
    }
}
