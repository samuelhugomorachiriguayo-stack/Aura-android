# Cómo subir AURA 7.0 a GitHub desde Android

Este archivo es solo una guía para la carga del paquete final.

En la rama `principal` debe existir, en la raíz del repositorio:

- `AURA_7_0_Free_Local_Autonomous.zip`
- la carpeta `.github/` con `workflows/build-apk.yml`

El workflow abre el ZIP, verifica su integridad y comprueba su SHA-256 antes de compilar.
No es necesario extraer el ZIP manualmente en el teléfono.
