# REGLA DE GRATUIDAD DE AURA

El núcleo de AURA debe funcionar sin APIs de IA de pago ni suscripciones.

- Cerebro local: llama.cpp + Qwen3-1.7B Q4_K_M.
- El modelo se descarga gratis desde Hugging Face.
- La compilación usa GitHub Actions en el repositorio público; GitHub indica que los runners estándar en repositorios públicos son gratuitos.
- Internet solo es necesario para descargar el modelo o usar funciones externas opcionales.
- No se requiere clave de OpenAI ni otra API de IA de pago.
- Las funciones externas como WhatsApp Business quedan fuera del núcleo local y no deben introducir costes en esta versión.
