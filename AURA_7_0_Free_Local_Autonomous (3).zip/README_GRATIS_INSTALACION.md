# AURA 7.0 — Instalación gratuita por GitHub Actions

## Qué incluye esta versión

AURA 7.0 es un núcleo Android local-first con:

- Qwen3-1.7B GGUF ejecutado localmente mediante llama.cpp.
- Voz de salida con Android TextToSpeech.
- Base de conocimiento offline temática para salud/medicina educativa, psicología, hipnosis/relajación, academia, Music Pro, soporte técnico y seguridad bancaria.
- Interfaz de chat local.
- Sin API de IA de pago ni claves de OpenAI u otros proveedores.

## Qué NO está integrado todavía en este APK

La expansión completa de AURA (memoria persistente avanzada, agente autónomo con herramientas, entrada de voz/escucha continua, funciones online gratuitas opcionales y conexión operativa con WhatsApp) se implementará después del primer APK funcional. No se debe confundir esta versión 7.0 con el producto final completo.

## Compilación

El workflow está en `.github/workflows/build-apk.yml`. GitHub Actions descarga el código fijado de llama.cpp, copia su proyecto Android oficial, compila un APK debug y publica el artefacto `AURA-7.0-free-local-autonomous-apk`.

## Modelo

El APK no incluye el modelo de 1.28 GB. La primera puesta en marcha descarga o selecciona `Qwen3-1.7B-Q4_K_M.gguf` desde el repositorio público de `ggml-org/Qwen3-1.7B-GGUF`.

## Seguridad

No subas credenciales, claves, tokens, archivos `.env` ni datos bancarios al repositorio.
