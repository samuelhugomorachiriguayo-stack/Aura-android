# AURA 7.0

- Añadidos módulos de Psicología, Hipnosis/Relajación, Salud/Medicina y Cirugía educativa.
- Añadida Academia para cursos, ejercicios y evaluaciones.
- Reforzado Music Pro y soporte técnico.
- Reglas explícitas de privacidad y seguridad para banca.
- Añadida base de conocimiento offline por temas, usada como contexto de consulta por el cerebro local.
- Añadidas reglas para no presentar a AURA como profesional sanitario ni dar instrucciones peligrosas de cirugía.
- Sigue siendo local-first y sin APIs de IA de pago.
