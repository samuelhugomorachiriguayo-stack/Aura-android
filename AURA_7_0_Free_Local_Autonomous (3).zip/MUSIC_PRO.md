# AURA Music Pro 🎵❤️

Music Pro está incorporado como instrucciones y conocimiento local del núcleo Android de AURA 7.0.

## Áreas
- Rap / Hip-Hop: flow, métrica, rimas, hooks y estructura.
- Reggaetón: dembow, groove, hooks, energía y arreglos.
- DJ: BPM, beatmatching, tonalidad, transiciones y construcción de sets.
- Beatmaking: batería, bajo, percusión y programación.
- Composición: letras originales, melodías, acordes y estructuras.
- Producción y arreglo.
- Diseño sonoro.
- Análisis musical.
- Mezcla y mastering.
- Versatilidad multigénero.

## Formato útil
Cuando ayude, AURA puede responder en este orden:
**BPM → tonalidad → groove → instrumentación → estructura → transiciones → mezcla → master.**

El módulo es local y proveedor-agnóstico. No depende de una API de IA de pago.
