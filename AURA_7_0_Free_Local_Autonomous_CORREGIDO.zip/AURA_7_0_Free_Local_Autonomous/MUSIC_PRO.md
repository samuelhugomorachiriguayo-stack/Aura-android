# AURA Music Pro 🎵❤️

Music Pro ya no es solo un archivo descriptivo: su prompt se incorpora directamente al cerebro de AURA en `server/app/main.py`.

## Áreas
- Rap / Hip-Hop: flow, métrica, rimas, hooks y estructura.
- Reggaetón: dembow, groove, hooks, energía y arreglos.
- DJ: BPM, beatmatching, tonalidad, transiciones y construcción de sets.
- Beatmaking: drums, bajo, percusión y programación.
- Composición: letras originales, melodías, acordes y estructuras.
- Producción y arreglo.
- Diseño sonoro.
- Análisis musical.
- Mezcla y mastering.
- Versatilidad multigénero.

## Formato útil
Cuando ayude, AURA puede responder en este orden:
**BPM → tonalidad → groove → instrumentación → estructura → transiciones → mezcla → master.**

El módulo es proveedor-agnóstico: puede funcionar con distintos cerebros IA sin cambiar la identidad de AURA.
