# AURA 6.3 — Instalación gratuita por GitHub Actions

## Lo que contiene

AURA 6.3 integra Android, cerebro online configurable, memoria conversacional, Music Pro y webhook oficial de WhatsApp Cloud API.

## Compilación

El workflow está en `.github/workflows/build-apk.yml`. GitHub Actions compila un APK debug y lo publica como artifact.

## Importante

El proyecto no contiene claves reales. Para conectar el APK a un backend real, configura `AURA_BASE_URL` y `AURA_AUTH_TOKEN` como Secrets de GitHub y vuelve a ejecutar el workflow.

Para WhatsApp, despliega `server/` en un servicio HTTPS, configura las variables de Meta y registra `/api/whatsapp/webhook` en la aplicación de Meta.

**No subas nunca un archivo `.env` con claves reales al repositorio.**
