# SIGUIENTE PASO

1. Subir el contenido del proyecto a la rama `principal`.
2. Abrir GitHub Actions y ejecutar `Construir AURA 6.4 — Cerebro Local Gratis`.
3. Si termina en verde, descargar el artefacto `AURA-6.4-free-local-apk`.
4. Instalar el APK.
5. Descargar `Qwen3-1.7B-Q4_K_M.gguf` y usar `Seleccionar modelo GGUF`.
6. Probar primero sin Internet para confirmar el cerebro local.
