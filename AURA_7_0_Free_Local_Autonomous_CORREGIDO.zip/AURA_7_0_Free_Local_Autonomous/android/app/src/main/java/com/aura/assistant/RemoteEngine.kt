package com.aura.assistant

/** Online engine intentionally disabled in AURA 6.4 free core. */
class RemoteEngine {
    fun health(): Boolean = false
    fun chat(userId: String, message: String): String? = null
}
