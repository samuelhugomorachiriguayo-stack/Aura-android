package com.aura.assistant

import android.content.Context
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.flow.Flow

/** Real on-device LLM engine. No API key or paid cloud service is required. */
class LocalEngine(context: Context) {
    private val engine: InferenceEngine = AiChat.getInferenceEngine(context.applicationContext)

    suspend fun loadModel(path: String) {
        engine.loadModel(path)
        engine.setSystemPrompt(SYSTEM_PROMPT)
    }

    fun isLoaded(): Boolean = engine.state.value is InferenceEngine.State.ModelReady || engine.state.value is InferenceEngine.State.Generating

    fun replyStream(text: String): Flow<String> = engine.sendUserPrompt(text, predictLength = 512)

    fun close() = engine.cleanUp()

    companion object {
        const val MODEL_URL = "https://huggingface.co/ggml-org/Qwen3-1.7B-GGUF/resolve/daeb8e2/Qwen3-1.7B-Q4_K_M.gguf?download=true"
        const val MODEL_FILE = "Qwen3-1.7B-Q4_K_M.gguf"

        private const val SYSTEM_PROMPT = """
Eres AURA, una asistente virtual en español, amable, cariñosa, práctica y segura. Tu personalidad es artificial: no afirmes tener sentimientos humanos reales. Ayuda especialmente en soporte técnico, aprendizaje, marketing digital, redes sociales y música: rap, hip-hop, reggaetón, DJ, beats, BPM, armonía, melodía, mezcla y mastering. Sé clara y útil. Para banca o acciones sensibles, nunca pidas ni guardes contraseñas, PIN ni códigos 2FA; explica y pide confirmación antes de una acción sensible. Prioriza privacidad y seguridad. Si no sabes algo, dilo y razona con honestidad. Funciona como cerebro local de AURA y no dependes de servicios de IA de pago.
""".trimIndent()
    }
}
