package com.aura.assistant

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.cancel
import java.io.File
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var localEngine: LocalEngine
    private lateinit var status: TextView
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private var tts: TextToSpeech? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val picker = 6404

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        chat = findViewById(R.id.chat)
        input = findViewById(R.id.input)
        localEngine = LocalEngine(this)
        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) tts?.language = Locale("es", "ES")
        }

        findViewById<Button>(R.id.downloadModel).setOnClickListener { downloadModel() }
        findViewById<Button>(R.id.selectModel).setOnClickListener { selectModel() }
        findViewById<Button>(R.id.send).setOnClickListener { send() }
        restoreBundledModelIfPresent()
    }

    private fun downloadModel() {
        val request = DownloadManager.Request(Uri.parse(LocalEngine.MODEL_URL))
            .setTitle("AURA — cerebro local gratuito")
            .setDescription("Qwen3-1.7B Q4_K_M · 1.28 GB aprox.")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, LocalEngine.MODEL_FILE)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
        val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
        Toast.makeText(this, "Descarga iniciada. Cuando termine, toca Seleccionar modelo GGUF.", Toast.LENGTH_LONG).show()
    }

    private fun selectModel() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
        }
        startActivityForResult(intent, picker)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != picker || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        scope.launch(Dispatchers.IO) {
            val target = File(filesDir, LocalEngine.MODEL_FILE)
            contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } }
            loadModel(target)
        }
    }

    private fun restoreBundledModelIfPresent() {
        val target = File(filesDir, LocalEngine.MODEL_FILE)
        if (target.exists()) loadModel(target)
    }

    private fun loadModel(file: File) {
        scope.launch(Dispatchers.IO) {
            try {
                withContext(Dispatchers.Main) { status.text = "🧠 Cargando cerebro local…" }
                localEngine.loadModel(file.absolutePath)
                withContext(Dispatchers.Main) {
                    status.text = "🧠 AURA ❤️ • CEREBRO LOCAL ACTIVO • SIN API DE PAGO"
                    chat.text = "AURA: Ya estoy lista ❤️. Mi cerebro está ejecutándose en tu teléfono."
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    status.text = "⚠️ No pude cargar el modelo"
                    chat.text = "AURA: Revisa que hayas seleccionado un archivo GGUF compatible.\n\nError: ${e.message}"
                }
            }
        }
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        if (!localEngine.isLoaded()) {
            Toast.makeText(this, "Primero descarga o selecciona el modelo GGUF.", Toast.LENGTH_SHORT).show()
            return
        }
        input.text.clear()
        chat.append("\n\nTú: $text\nAURA: ")
        scope.launch {
            try {
                val answer = StringBuilder()
                localEngine.replyStream(text).collect { token ->
                    answer.append(token)
                    chat.append(token)
                }
                val speech = answer.toString().trim()
                if (speech.isNotEmpty()) tts?.speak(speech, TextToSpeech.QUEUE_FLUSH, null, "aura_reply")
            } catch (e: Exception) {
                chat.append("\n⚠️ Error local: ${e.message}")
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        localEngine.close()
        scope.cancel()
        super.onDestroy()
    }
}
