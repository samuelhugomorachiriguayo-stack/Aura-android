# AURA 6.4 — Cerebro Local Gratis

Aplicación Android local-first para ejecutar AURA en el teléfono con llama.cpp y Qwen3-1.7B GGUF. No usa una API de IA de pago para el cerebro.

## Seguridad y estabilidad
- Dependencias nativas basadas en la versión `b10516` de llama.cpp.
- El workflow verifica el commit esperado antes de compilar.
- El modelo está fijado a una revisión concreta de Hugging Face.
- El núcleo no incluye servidor ni proveedor de IA en la nube.
