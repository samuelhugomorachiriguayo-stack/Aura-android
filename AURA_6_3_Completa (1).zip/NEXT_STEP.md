# PRÓXIMO PASO

1. Subir **el contenido del proyecto**, no el ZIP como un solo archivo, al repositorio de GitHub.
2. GitHub Actions compilará `android/app/build/outputs/apk/debug/app-debug.apk`.
3. Para usar el cerebro online desde el Redmi, configurar `AURA_BASE_URL` y `AURA_AUTH_TOKEN` como secretos de GitHub.
4. Para activar WhatsApp, desplegar `server/` en un host HTTPS y conectar el webhook `/api/whatsapp/webhook` en Meta.
5. Para compartir identidad entre Android y WhatsApp, usar `/v1/memory/{user_id}/link` para vincular el ID de Android con `wa:<telefono>`.
