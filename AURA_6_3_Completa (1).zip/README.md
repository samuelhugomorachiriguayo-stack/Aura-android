# AURA 6.3 — Cerebro híbrido + Music Pro + WhatsApp

AURA es una asistente híbrida: Android + backend central + memoria compartida + WhatsApp Cloud API.

## Incluido
- Cerebro online configurable (OpenAI Responses o cualquier proveedor compatible).
- Modo DEMO si no hay proveedor configurado.
- Modo offline básico en Android.
- Memoria SQLite y conversaciones recientes.
- Posibilidad de vincular IDs de canales a una identidad canónica.
- Voz TTS en español.
- Soporte técnico, marketing, redes y orientación bancaria con reglas de seguridad.
- **AURA Music Pro** integrado directamente en el prompt del cerebro.
- Webhook oficial para **WhatsApp Cloud API / Meta** y respuesta de mensajes de texto.
- Verificación de firma `X-Hub-Signature-256` cuando se configura `WHATSAPP_APP_SECRET`.
- GitHub Actions para compilar el APK gratuitamente en un repositorio público.

## Music Pro
AURA está preparada para rap, hip-hop, reggaetón, DJing, beatmaking, composición, melodía,
armonía, arreglos, producción, diseño sonoro, análisis musical, BPM, tonalidad, transiciones,
mezcla, mastering y planificación de sets. El contenido se genera de forma original y no intenta
imitar de forma exacta el estilo distintivo de un artista vivo.

## Seguridad
Las claves privadas viven en el servidor o en secretos de GitHub; no deben escribirse en el APK ni
subirse al repositorio. En banca nunca se piden contraseñas, PIN, CVV ni códigos 2FA.

## Servidor
```bash
cd server
python -m venv .venv
# activar el entorno virtual
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## WhatsApp
Configura en `.env`:
- `WHATSAPP_ACCESS_TOKEN`
- `WHATSAPP_PHONE_NUMBER_ID`
- `WHATSAPP_VERIFY_TOKEN`
- `WHATSAPP_APP_SECRET` (recomendado)
- `WHATSAPP_GRAPH_API_VERSION`

Webhook:
`https://TU-DOMINIO/api/whatsapp/webhook`

La URL de verificación debe usar `hub.mode`, `hub.verify_token` y `hub.challenge` como parámetros de Meta.

## Android
El APK toma `AURA_BASE_URL` y `AURA_AUTH_TOKEN` desde variables de entorno de Gradle.
Para una compilación de prueba, GitHub Actions puede usar placeholders; para una conexión real,
configura estos valores como **GitHub Repository Secrets**.
