package com.aura.assistant

import com.google.gson.Gson
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import java.util.concurrent.TimeUnit

class RemoteEngine {
    private val client = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    private val baseUrl = BuildConfig.AURA_BASE_URL.trimEnd('/')
    private val token = BuildConfig.AURA_AUTH_TOKEN

    fun chat(userId: String, message: String): String? {
        if (baseUrl.isBlank() || baseUrl.contains("YOUR-AURA-SERVER")) return null
        val body = Gson().toJson(mapOf("user_id" to userId, "message" to message))
            .toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url("$baseUrl/v1/chat")
            .addHeader("Authorization", "Bearer $token")
            .post(body).build()
        return try {
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful || r.body == null) null
                else Gson().fromJson(r.body!!.string(), Map::class.java)["reply"]?.toString()
            }
        } catch (_: Exception) { null }
    }

    fun health(): Boolean {
        if (baseUrl.isBlank() || baseUrl.contains("YOUR-AURA-SERVER")) return false
        val req = Request.Builder().url("$baseUrl/health").get().build()
        return try { client.newCall(req).execute().use { it.isSuccessful } } catch (_: Exception) { false }
    }
}
