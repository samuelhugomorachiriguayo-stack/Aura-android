package com.aura.assistant

class LocalEngine {
    fun reply(text: String): String {
        val t = text.lowercase()
        return when {
            "música" in t || "musica" in t || "rap" in t || "hip hop" in t || "reggaeton" in t || "reguetón" in t || "dj" in t || "beat" in t ->
                "Estoy en modo offline 🎵. Puedo ayudarte con ideas de beats, BPM, estructura, rimas, melodías, armonía, mezcla y mastering; cuando vuelva internet activaré mi Music Pro completo."
            "hola" in t -> "Hola ❤️ Soy AURA. Estoy aquí contigo."
            "soporte" in t || "técnico" in t -> "Claro 🥰. Puedo ayudarte a revisar el problema paso a paso."
            "marketing" in t -> "Puedo ayudarte con campañas, contenido, anuncios y estrategia digital."
            "banco" in t || "bancaria" in t -> "Puedo orientarte, pero las operaciones sensibles requieren confirmación y nunca necesito tu PIN o contraseña."
            "redes" in t || "instagram" in t || "facebook" in t -> "Puedo ayudarte a planificar contenido y mejorar tu presencia en redes."
            else -> "Ahora estoy en modo offline ❤️. Puedo seguir ayudándote con tareas básicas; cuando vuelva internet usaré mi cerebro online."
        }
    }
}
