package com.aura.assistant
import android.app.Activity
import android.os.Bundle
import android.widget.*
import kotlinx.coroutines.*
import android.speech.tts.TextToSpeech
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private val router = HybridRouter()
    private val userId = "local-user"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tts = TextToSpeech(this, this)
        val input = findViewById<EditText>(R.id.input)
        val chat = findViewById<TextView>(R.id.chat)
        val status = findViewById<TextView>(R.id.status)
        findViewById<Button>(R.id.send).setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            chat.text = "Tú: $text\n\nAURA está pensando..."
            input.text.clear()
            CoroutineScope(Dispatchers.IO).launch {
                val (reply, online) = router.reply(userId, text)
                withContext(Dispatchers.Main) {
                    status.text = if (online) "AURA ❤️ • ONLINE" else "AURA ❤️ • OFFLINE"
                    chat.text = "Tú: $text\n\nAURA: $reply"
                    tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "aura")
                }
            }
        }
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts.language = Locale("es", "ES") }
    override fun onDestroy() { tts.shutdown(); super.onDestroy() }
}
