package com.aura.assistant
class HybridRouter {
    private val remote = RemoteEngine()
    private val local = LocalEngine()
    fun reply(userId: String, text: String): Pair<String, Boolean> {
        val online = remote.health()
        if (online) remote.chat(userId, text)?.let { return it to true }
        return local.reply(text) to false
    }
}
