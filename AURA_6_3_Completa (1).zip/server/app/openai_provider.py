import os
import httpx

class OpenAIResponsesProvider:
    def __init__(self):
        self.api_key = os.getenv("OPENAI_API_KEY", "")
        self.model = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")
        self.base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")

    async def chat(self, system: str, user: str) -> str:
        if not self.api_key:
            raise RuntimeError("OPENAI_API_KEY no configurada")
        payload = {
            "model": self.model,
            "instructions": system,
            "input": user,
        }
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        async with httpx.AsyncClient(timeout=90) as client:
            r = await client.post(f"{self.base_url}/responses", headers=headers, json=payload)
            r.raise_for_status()
            data = r.json()
        # Responses API commonly returns output_text; fallback parses output blocks.
        if data.get("output_text"):
            return data["output_text"]
        texts = []
        for item in data.get("output", []):
            for c in item.get("content", []):
                if c.get("type") in ("output_text", "text") and c.get("text"):
                    texts.append(c["text"])
        return "\n".join(texts) or "No recibí texto del modelo."
