from abc import ABC, abstractmethod


class AIProvider(ABC):
    @abstractmethod
    async def chat(self, system: str, user: str) -> str:
        raise NotImplementedError


class DemoProvider(AIProvider):
    async def chat(self, system: str, user: str) -> str:
        return (
            "Soy AURA ❤️. El servidor está funcionando, pero el proveedor de IA "
            "online está en modo DEMO. Configura un proveedor compatible en .env "
            "para activar el cerebro online."
        )
