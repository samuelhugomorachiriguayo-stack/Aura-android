import sqlite3
from pathlib import Path
from typing import Optional

DB = Path(__file__).resolve().parent.parent / "aura.db"


def _connect():
    con = sqlite3.connect(DB)
    con.execute("PRAGMA journal_mode=WAL")
    return con


def init_db():
    con = _connect()
    con.execute("CREATE TABLE IF NOT EXISTS memory (user_id TEXT PRIMARY KEY, name TEXT)")
    con.execute(
        """CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )"""
    )
    con.execute("CREATE INDEX IF NOT EXISTS idx_messages_user_id ON messages(user_id, id DESC)")
    con.execute(
        """CREATE TABLE IF NOT EXISTS identity_links (
            user_id TEXT PRIMARY KEY,
            canonical_user_id TEXT NOT NULL
        )"""
    )
    con.commit()
    con.close()


def canonical_user_id(user_id: str) -> str:
    con = _connect()
    row = con.execute(
        "SELECT canonical_user_id FROM identity_links WHERE user_id=?", (user_id,)
    ).fetchone()
    con.close()
    return row[0] if row else user_id


def link_user(user_id: str, canonical_id: str):
    con = _connect()
    con.execute(
        "INSERT INTO identity_links(user_id, canonical_user_id) VALUES(?, ?) "
        "ON CONFLICT(user_id) DO UPDATE SET canonical_user_id=excluded.canonical_user_id",
        (user_id, canonical_id),
    )
    con.commit()
    con.close()


def get_name(user_id: str) -> Optional[str]:
    user_id = canonical_user_id(user_id)
    con = _connect()
    row = con.execute("SELECT name FROM memory WHERE user_id=?", (user_id,)).fetchone()
    con.close()
    return row[0] if row else None


def set_name(user_id: str, name: str):
    user_id = canonical_user_id(user_id)
    con = _connect()
    con.execute(
        "INSERT INTO memory(user_id,name) VALUES(?,?) "
        "ON CONFLICT(user_id) DO UPDATE SET name=excluded.name",
        (user_id, name),
    )
    con.commit()
    con.close()


def save_message(user_id: str, role: str, content: str):
    user_id = canonical_user_id(user_id)
    con = _connect()
    con.execute(
        "INSERT INTO messages(user_id, role, content) VALUES(?,?,?)",
        (user_id, role, content),
    )
    con.commit()
    con.close()


def recent_messages(user_id: str, limit: int = 12):
    user_id = canonical_user_id(user_id)
    limit = max(1, min(int(limit), 30))
    con = _connect()
    rows = con.execute(
        "SELECT role, content FROM messages WHERE user_id=? ORDER BY id DESC LIMIT ?",
        (user_id, limit),
    ).fetchall()
    con.close()
    return list(reversed(rows))
