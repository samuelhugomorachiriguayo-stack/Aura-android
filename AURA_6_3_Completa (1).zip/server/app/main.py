import hashlib
import hmac
import os
import re
from typing import Any

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, Field

from .ai_provider import DemoProvider
from .memory_store import (
    canonical_user_id,
    get_name,
    init_db,
    link_user,
    recent_messages,
    save_message,
    set_name,
)
from .music_pro import MUSIC_PRO_SYSTEM_PROMPT
from .openai_compatible import OpenAICompatibleProvider
from .openai_provider import OpenAIResponsesProvider

load_dotenv()
app = FastAPI(title="AURA Brain", version="6.3.0")
init_db()


def auth(authorization: str | None):
    expected = os.getenv("AURA_AUTH_TOKEN", "").strip()
    if not expected:
        raise HTTPException(status_code=503, detail="AURA_AUTH_TOKEN no configurado en el servidor")
    if authorization != f"Bearer {expected}":
        raise HTTPException(status_code=401, detail="Unauthorized")


def provider():
    mode = os.getenv("AI_PROVIDER", "demo").lower().strip()
    if mode == "openai":
        return OpenAIResponsesProvider()
    if mode == "openai_compatible":
        return OpenAICompatibleProvider(
            os.getenv("AI_API_KEY", ""),
            os.getenv("AI_BASE_URL", ""),
            os.getenv("AI_MODEL", ""),
        )
    return DemoProvider()


SYSTEM = f"""
Eres AURA, una asistente virtual femenina, amable, clara, cercana y cariñosa.
Tu identidad y memoria deben mantenerse consistentes entre canales autorizados.
Ayudas con soporte técnico, marketing digital, redes sociales y orientación bancaria.

SEGURIDAD:
- Para banca o acciones sensibles debes pedir confirmación antes de ejecutar una acción.
- Nunca solicites ni almacenes contraseñas, PIN, CVV, semillas, códigos 2FA ni credenciales.
- Usa únicamente integraciones oficiales cuando se conecten servicios externos.
- No presentes como completada una acción que el sistema no haya confirmado.

MÚSICA — AURA MUSIC PRO:
{MUSIC_PRO_SYSTEM_PROMPT}
"""


class ChatIn(BaseModel):
    user_id: str = Field(min_length=1, max_length=200)
    message: str = Field(min_length=1, max_length=12000)


class MemoryIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)


class LinkIn(BaseModel):
    canonical_user_id: str = Field(min_length=1, max_length=200)


async def generate_reply(user_id: str, message: str) -> str:
    user_id = canonical_user_id(user_id)
    name = get_name(user_id)
    match = re.search(
        r"\b(?:me llamo|mi nombre es)\s+([A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,50})$",
        message,
        re.I,
    )
    if match:
        name = match.group(1).strip()
        set_name(user_id, name)

    context = f"El usuario se llama {name}." if name else "No conocemos el nombre del usuario."
    history = recent_messages(user_id, 12)
    history_text = "\n".join(f"{role}: {content}" for role, content in history)
    prompt = f"{context}\nHistorial reciente:\n{history_text}\n\nUsuario: {message}"

    save_message(user_id, "user", message)
    reply = await provider().chat(SYSTEM, prompt)
    save_message(user_id, "assistant", reply)
    return reply


@app.get("/health")
async def health():
    return {
        "ok": True,
        "version": "6.3.0",
        "ai_provider": os.getenv("AI_PROVIDER", "demo"),
        "whatsapp_enabled": bool(os.getenv("WHATSAPP_ACCESS_TOKEN") and os.getenv("WHATSAPP_PHONE_NUMBER_ID")),
    }


@app.post("/v1/chat")
async def chat(body: ChatIn, authorization: str | None = Header(default=None)):
    auth(authorization)
    try:
        reply = await generate_reply(body.user_id, body.message.strip())
        return {"reply": reply, "online": True, "user_id": canonical_user_id(body.user_id)}
    except Exception:
        return {
            "reply": "No pude conectar con mi cerebro online en este momento ❤️. Prueba de nuevo o seguiré en modo local.",
            "online": False,
        }


@app.get("/v1/memory/{user_id}")
async def memory(user_id: str, authorization: str | None = Header(default=None)):
    auth(authorization)
    uid = canonical_user_id(user_id)
    return {"user_id": uid, "name": get_name(uid), "recent_messages": recent_messages(uid, 10)}


@app.post("/v1/memory/{user_id}")
async def memory_set(user_id: str, body: MemoryIn, authorization: str | None = Header(default=None)):
    auth(authorization)
    set_name(user_id, body.name.strip())
    return {"ok": True, "user_id": canonical_user_id(user_id), "name": body.name.strip()}


@app.post("/v1/memory/{user_id}/link")
async def memory_link(user_id: str, body: LinkIn, authorization: str | None = Header(default=None)):
    auth(authorization)
    link_user(user_id, body.canonical_user_id.strip())
    return {"ok": True, "user_id": user_id, "canonical_user_id": body.canonical_user_id.strip()}


# ---------------- WhatsApp Cloud API webhook ----------------

def _wa_configured() -> bool:
    return bool(os.getenv("WHATSAPP_ACCESS_TOKEN") and os.getenv("WHATSAPP_PHONE_NUMBER_ID"))


def _verify_meta_signature(raw_body: bytes, signature: str | None) -> bool:
    app_secret = os.getenv("WHATSAPP_APP_SECRET", "").strip()
    if not app_secret:
        return True
    if not signature or not signature.startswith("sha256="):
        return False
    expected = hmac.new(app_secret.encode(), raw_body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(signature.split("=", 1)[1], expected)


@app.get("/api/whatsapp/webhook")
async def whatsapp_verify(
    hub_mode: str | None = None,
    hub_verify_token: str | None = None,
    hub_challenge: str | None = None,
):
    verify_token = os.getenv("WHATSAPP_VERIFY_TOKEN", "").strip()
    if hub_mode == "subscribe" and hub_verify_token and verify_token and hmac.compare_digest(hub_verify_token, verify_token):
        return PlainTextResponse(hub_challenge or "")
    raise HTTPException(status_code=403, detail="Webhook verification failed")


async def send_whatsapp_text(to: str, text: str):
    if not _wa_configured():
        raise RuntimeError("WhatsApp no configurado")
    graph_version = os.getenv("WHATSAPP_GRAPH_API_VERSION", "").strip()
    if not graph_version:
        raise RuntimeError("WHATSAPP_GRAPH_API_VERSION no configurado")
    phone_id = os.environ["WHATSAPP_PHONE_NUMBER_ID"]
    token = os.environ["WHATSAPP_ACCESS_TOKEN"]
    url = f"https://graph.facebook.com/{graph_version}/{phone_id}/messages"
    payload = {
        "messaging_product": "whatsapp",
        "to": to,
        "type": "text",
        "text": {"preview_url": False, "body": text},
    }
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(url, headers=headers, json=payload)
        response.raise_for_status()
        return response.json()


@app.post("/api/whatsapp/webhook")
async def whatsapp_webhook(request: Request, x_hub_signature_256: str | None = Header(default=None)):
    raw = await request.body()
    if not _verify_meta_signature(raw, x_hub_signature_256):
        raise HTTPException(status_code=403, detail="Invalid webhook signature")

    try:
        data: dict[str, Any] = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON")

    # Meta sends many event types. We only answer inbound text messages.
    for entry in data.get("entry", []):
        for change in entry.get("changes", []):
            value = change.get("value", {})
            for message in value.get("messages", []):
                if message.get("type") != "text":
                    continue
                sender = str(message.get("from", "")).strip()
                text = str(message.get("text", {}).get("body", "")).strip()
                if not sender or not text:
                    continue
                user_id = f"wa:{sender}"
                try:
                    reply = await generate_reply(user_id, text)
                    await send_whatsapp_text(sender, reply)
                except Exception as exc:
                    # Keep webhook idempotent and don't expose provider errors to Meta.
                    print(f"AURA WhatsApp error: {exc}")
    return {"ok": True}
