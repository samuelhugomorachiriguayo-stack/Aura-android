# Conectar AURA con WhatsApp

Este proyecto ya contiene el backend necesario para recibir mensajes de texto de WhatsApp Cloud API y responder usando el mismo cerebro y memoria central de AURA.

## Variables
Configura en el servidor:

- `WHATSAPP_ACCESS_TOKEN`: token de acceso de Meta.
- `WHATSAPP_PHONE_NUMBER_ID`: ID del número de WhatsApp conectado a la aplicación de Meta.
- `WHATSAPP_VERIFY_TOKEN`: token inventado por ti para la verificación inicial del webhook.
- `WHATSAPP_APP_SECRET`: secreto de la app de Meta para validar `X-Hub-Signature-256`.
- `WHATSAPP_GRAPH_API_VERSION`: versión de Graph API que muestre tu aplicación de Meta.

No pongas estos secretos en GitHub en archivos `.env` ni dentro del APK. Usa los Secrets/Environment Variables del servicio donde despliegues el backend.

## Webhook

URL pública:

`https://TU-DOMINIO/api/whatsapp/webhook`

Método de verificación: `GET`.

Eventos entrantes: `POST`.

AURA responde mensajes de texto entrantes. Los eventos que no contienen mensajes de texto se aceptan y se ignoran para evitar reintentos innecesarios.

## Importante

Para contestar dentro de la ventana de atención iniciada por el usuario se usa un mensaje de texto normal. Los envíos proactivos fuera de las reglas de WhatsApp requieren plantillas aprobadas y no forman parte de este primer puente.
