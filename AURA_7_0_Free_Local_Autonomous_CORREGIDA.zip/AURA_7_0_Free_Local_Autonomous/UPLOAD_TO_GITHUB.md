# Subir AURA 7.0 corregida a GitHub desde Android

1. Crea o abre el repositorio de AURA en GitHub.
2. Sube **el contenido de esta carpeta**, incluida la carpeta `.github`.
3. En la raíz del repositorio deben quedar, entre otros:
   - `android/`
   - `.github/workflows/build-apk.yml`
   - `README.md`
4. No hace falta subir un ZIP dentro del repositorio.
5. Abre **Actions** y ejecuta `Construir AURA 7.0 — Cerebro Local Gratis`.
6. Cuando termine correctamente, abre la ejecución y descarga el artefacto:
   `AURA-7.0-free-local-autonomous-apk`

El workflow ya no busca un ZIP dentro del repositorio. Usa directamente el proyecto Android y descarga la integración Android oficial de llama.cpp durante la compilación.
