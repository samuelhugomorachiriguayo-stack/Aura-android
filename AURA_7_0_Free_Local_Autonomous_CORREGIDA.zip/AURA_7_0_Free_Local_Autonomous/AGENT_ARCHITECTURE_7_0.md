# AURA 7.0 — arquitectura de agente local

AURA 7.0 combina un LLM local con una capa de agente ligera y determinista.

Flujo base: **entrada → plan → herramienta local cuando corresponde → observación → respuesta del modelo → memoria local**.

Herramientas incluidas en esta versión: hora, fecha y memoria local explícita. La memoria se guarda con SharedPreferences en el dispositivo.

La ejecución de herramientas sensibles no está automatizada: las futuras acciones sobre banca, mensajería, dispositivo o cuentas deben pasar por una capa de permisos y confirmación.

El modelo es Qwen3-1.7B Q4_K_M GGUF y se ejecuta mediante la integración Android oficial de llama.cpp. El modelo no se distribuye dentro del APK; el usuario lo descarga gratuitamente y lo importa desde el dispositivo.
