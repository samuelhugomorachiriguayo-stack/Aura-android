# SIGUIENTE PASO — AURA 7.0 CORREGIDA

1. Subir el contenido de este proyecto a la rama principal de GitHub.
2. Abrir **Actions**.
3. Ejecutar `Construir AURA 7.0 — Cerebro Local Gratis`.
4. Esperar a que termine la compilación.
5. Si termina en verde, descargar `AURA-7.0-free-local-autonomous-apk`.
6. Instalar el APK en Android.
7. Descargar o seleccionar `Qwen3-1.7B-Q4_K_M.gguf` desde la propia aplicación.
8. Probar primero el chat local sin Internet.

Importante: esta versión corrige el proceso de compilación. WhatsApp todavía no está integrado en este APK y se trabajará después de comprobar que el cerebro local compila y funciona.
