# AURA 7.0 — Instalación gratuita por GitHub Actions

## Qué incluye

- Núcleo Android local-first.
- Qwen3-1.7B GGUF ejecutado localmente mediante la integración Android de llama.cpp.
- Voz mediante Android TextToSpeech.
- Conocimiento offline temático.
- Interfaz de chat local.
- Sin API de IA de pago ni claves de proveedores externos.

## Qué corrige esta versión

La versión anterior esperaba encontrar un ZIP de AURA dentro del propio repositorio. Eso podía impedir la compilación cuando el ZIP no estaba allí.

La versión corregida compila directamente la carpeta `android/` del repositorio y obtiene durante el workflow la integración Android oficial de llama.cpp.

## Qué todavía no significa

Un APK compilado no significa que todas las funciones finales de AURA estén terminadas. Después de obtener un APK funcional todavía hay que probar el modelo, memoria, herramientas, voz y, por separado, la conexión con WhatsApp.

## Modelo

El APK no incluye el modelo de aproximadamente 1.28 GB. La aplicación permite seleccionar el archivo GGUF y contiene una opción para iniciar su descarga.

## Seguridad

No subas contraseñas, PIN, códigos 2FA, tokens, claves API ni datos bancarios al repositorio.
