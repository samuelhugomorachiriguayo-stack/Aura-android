# AURA 7.0 ❤️ — asistente local gratuita

AURA 7.0 es un proyecto Android **local-first**: el cerebro Qwen3-1.7B se ejecuta en el propio teléfono mediante llama.cpp. No requiere una API de IA de pago.

## Base técnica

- Android 33+
- Java/Kotlin 17
- llama.cpp Android oficial, fijado en b10516 / commit b95502b
- Modelo Qwen3-1.7B Q4_K_M GGUF
- Conocimientos offline en `app/src/main/assets/knowledge/`
- Memoria local explícita
- Herramientas locales básicas y orquestación agente
- Voz mediante Android TextToSpeech

## Construcción reproducible

El workflow de GitHub Actions descarga el ejemplo Android oficial de llama.cpp en tiempo de compilación, integra el código AURA y ejecuta `:app:assembleDebug`.

El ZIP debe conservar esta estructura:

`AURA_7_0_Free_Local_Autonomous/android/...`

No se debe editar manualmente el código de llama.cpp ni sustituir sus archivos nativos por implementaciones parciales.

## Gratis

El proyecto no necesita claves de APIs comerciales. El modelo GGUF se descarga desde Hugging Face y la compilación puede ejecutarse en GitHub Actions para repositorios públicos.

## Seguridad

AURA no debe solicitar ni almacenar contraseñas, PIN, claves privadas o códigos 2FA. La salud y la psicología se presentan con fines educativos y con límites de seguridad.
