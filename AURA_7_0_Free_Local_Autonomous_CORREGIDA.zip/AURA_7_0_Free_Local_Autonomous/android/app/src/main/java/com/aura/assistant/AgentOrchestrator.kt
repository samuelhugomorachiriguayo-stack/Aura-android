package com.aura.assistant

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

/**
 * Lightweight local agent loop: plan -> tool -> observation -> response.
 * Tool execution stays deterministic and local; the LLM is used for natural-language synthesis.
 */
class AgentOrchestrator(
    private val localEngine: LocalEngine,
    private val tools: LocalTools
) {
    fun run(userText: String): Flow<String> {
        val observation = tools.run(userText)
        if (observation != null) {
            if (!localEngine.isLoaded()) {
                return flowOf("AURA: ${observation.result}")
            }
            val prompt = """
                El usuario pidió: $userText
                Herramienta local ejecutada: ${observation.tool}
                Observación: ${observation.result}
                Responde al usuario en español de forma breve, natural y útil. No inventes datos.
            """.trimIndent()
            return localEngine.replyStream(prompt)
        }
        return localEngine.replyStream(userText)
    }
}
