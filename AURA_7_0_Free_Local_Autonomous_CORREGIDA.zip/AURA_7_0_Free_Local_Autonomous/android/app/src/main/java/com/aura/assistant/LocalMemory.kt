package com.aura.assistant

import android.content.Context

class LocalMemory(context: Context) {
    private val prefs = context.getSharedPreferences("aura_memory", Context.MODE_PRIVATE)

    fun remember(text: String) {
        val cleaned = text.trim().take(500)
        if (cleaned.isEmpty()) return
        val previous = prefs.getStringSet("notes", emptySet()).orEmpty().toMutableSet()
        previous.add(cleaned)
        while (previous.size > 50) previous.remove(previous.first())
        prefs.edit().putStringSet("notes", previous).apply()
    }

    fun recall(): List<String> = prefs.getStringSet("notes", emptySet()).orEmpty().toList().takeLast(20)
}
