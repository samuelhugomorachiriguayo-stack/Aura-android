package com.aura.assistant

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var localEngine: LocalEngine
    private lateinit var agent: AgentOrchestrator
    private lateinit var status: TextView
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private var tts: TextToSpeech? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val picker = 7000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        chat = findViewById(R.id.chat)
        input = findViewById(R.id.input)

        localEngine = LocalEngine(this)
        agent = AgentOrchestrator(localEngine, LocalTools(this))
        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) tts?.language = Locale("es", "ES")
        }

        findViewById<Button>(R.id.downloadModel).setOnClickListener { downloadModel() }
        findViewById<Button>(R.id.selectModel).setOnClickListener { selectModel() }
        findViewById<Button>(R.id.send).setOnClickListener { send() }
        restoreModelIfPresent()
    }

    private fun downloadModel() {
        val request = DownloadManager.Request(Uri.parse(LocalEngine.MODEL_URL))
            .setTitle("AURA — cerebro local gratuito")
            .setDescription("Qwen3-1.7B Q4_K_M · aproximadamente 1.28 GB")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, LocalEngine.MODEL_FILE)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
        (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
        Toast.makeText(this, "Descarga iniciada. Al terminar, selecciona el modelo GGUF.", Toast.LENGTH_LONG).show()
    }

    private fun selectModel() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
        }
        startActivityForResult(intent, picker)
    }

    @Deprecated("Deprecated in Android API 30; retained for simple compatibility with the project target.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != picker || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        scope.launch(Dispatchers.IO) {
            try {
                val target = File(filesDir, LocalEngine.MODEL_FILE)
                contentResolver.openInputStream(uri)?.use { source ->
                    target.outputStream().use { output -> source.copyTo(output) }
                } ?: throw IllegalArgumentException("No se pudo leer el archivo seleccionado")
                loadModel(target)
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    status.text = "⚠️ No pude copiar el modelo"
                    chat.text = "AURA: ${e.message ?: "Error desconocido"}"
                }
            }
        }
    }

    private fun restoreModelIfPresent() {
        val target = File(filesDir, LocalEngine.MODEL_FILE)
        if (target.isFile && target.length() > 1_000_000) loadModel(target)
    }

    private fun loadModel(file: File) {
        scope.launch(Dispatchers.IO) {
            try {
                withContext(Dispatchers.Main) { status.text = "🧠 Cargando cerebro local…" }
                localEngine.loadModel(file.absolutePath)
                withContext(Dispatchers.Main) {
                    status.text = "🧠 AURA ❤️ 7.0 • CEREBRO LOCAL ACTIVO • AGENTE LOCAL"
                    chat.text = "AURA: Lista ❤️\n\nMi cerebro está ejecutándose en este teléfono. Tengo memoria local y herramientas básicas sin API de pago."
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    status.text = "⚠️ No pude cargar el modelo"
                    chat.text = "AURA: Verifica que seleccionaste un GGUF compatible.\n\n${e.message ?: "Error desconocido"}"
                }
            }
        }
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        if (!localEngine.isLoaded()) {
            val observation = LocalTools(this).run(text)
            if (observation != null) {
                chat.append("\n\nTú: $text\nAURA: ${observation.result}")
                input.text.clear()
            } else {
                Toast.makeText(this, "Primero descarga o selecciona el modelo GGUF.", Toast.LENGTH_SHORT).show()
            }
            return
        }
        input.text.clear()
        chat.append("\n\nTú: $text\nAURA: ")
        scope.launch {
            try {
                val answer = StringBuilder()
                agent.run(text).collect { token ->
                    answer.append(token)
                    chat.append(token)
                }
                val speech = answer.toString().trim()
                if (speech.isNotEmpty()) tts?.speak(speech, TextToSpeech.QUEUE_FLUSH, null, "aura_reply")
            } catch (e: Exception) {
                chat.append("\n⚠️ Error local: ${e.message ?: "desconocido"}")
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        localEngine.close()
        scope.cancel()
        super.onDestroy()
    }
}
