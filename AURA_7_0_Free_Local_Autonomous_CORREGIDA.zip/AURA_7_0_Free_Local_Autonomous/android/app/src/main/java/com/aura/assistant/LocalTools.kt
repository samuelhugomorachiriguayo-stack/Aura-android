package com.aura.assistant

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Small deterministic local tools used by the agent before/alongside the LLM. */
class LocalTools(private val context: Context) {
    data class Observation(val tool: String, val result: String)

    fun run(query: String): Observation? {
        val q = query.trim().lowercase(Locale.ROOT)
        return when {
            q == "hora" || q.contains("qué hora") || q.contains("que hora") ->
                Observation("clock", SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()))
            q.contains("fecha de hoy") || q == "fecha" || q.contains("qué día es") || q.contains("que dia es") ->
                Observation("date", SimpleDateFormat("EEEE, d 'de' MMMM 'de' yyyy", Locale("es", "ES")).format(Date()))
            q.startsWith("recuerda ") || q.startsWith("recuerda que ") -> {
                val text = query.substringAfter("recuerda", "").trim().removePrefix("que").trim()
                LocalMemory(context).remember(text)
                Observation("memory", "Guardado en la memoria local del dispositivo.")
            }
            q.contains("qué recuerdas") || q.contains("que recuerdas") || q.contains("mis recuerdos") -> {
                val notes = LocalMemory(context).recall()
                Observation("memory", if (notes.isEmpty()) "No hay recuerdos guardados." else notes.joinToString("\n• ", prefix = "• "))
            }
            else -> null
        }
    }
}
