# Cómo subir AURA 7.0 a GitHub desde Android

GitHub no descomprime automáticamente un ZIP que subas al repositorio. Por eso, primero hay que extraer `AURA_6_3_Completa.zip` en el teléfono y después subir el contenido de la carpeta resultante.

La carpeta del proyecto debe mostrar directamente:

- `.github`
- `android`
- `server`
- `README.md`
- `render.yaml`
- los demás archivos del proyecto

No debe quedar una carpeta intermedia `AURA_6_3.../AURA_6_3.../`.
